@echo off
set PATH=C:\psyq\bin
set PSX_PATH=C:\psyq\bin
set LIBRARY_PATH=C:\psyq\lib
set C_PLUS_INCLUDE_PATH=C:\psyq\include
set C_INCLUDE_PATH=C:\psyq\include
set PSYQ_PATH=C:\psyq\bin
set COMPILER_PATH=C:\psyq\bin
set GO32=DPMISTACK 1000000
set G032TMP=C:\WINDOWS\TEMP
set TMPDIR=C:\WINDOWS\TEMP

ccpsx -O3 -Xo$80010000 main.c sio.c yoradio.c ui.c wipe.c -oyoradio.cpe,yoradio.sym,mem.map
cpe2x yoradio.cpe

del *.cpe
del *.sym
del *.map
move yoradio.exe .\buildcd\onegame
pause
cls