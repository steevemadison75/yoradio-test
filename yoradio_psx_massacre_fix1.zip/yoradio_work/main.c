#include <sys/types.h>
#include <libgte.h>
#include <libgpu.h>
#include <libetc.h>
#include "yoradio.h"
#include "ui.h"
#include "wipe.h"

#define UART_BAUD 115200UL      /* yoRadio's default UART speed */

int main(void)
{
    u_long pad, prev = 0, edge;
    init_Wipe();
    ui_init();                  /* ResetGraph first: it resets callbacks */
    PadInit(0);
    yo_init(UART_BAUD);

    for (;;) {
        pad  = PadRead(1) & 0xFFFF;
        edge = pad & ~prev;
        prev = pad;

        yo_poll();
        ui_input(pad, edge);
        ui_draw();
    }
    return 0;
}
