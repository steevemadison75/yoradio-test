/*
 * SIO1 driver for the PlayStation rear serial port.
 * Register map per psx-spx.  Receive is interrupt driven (IRQ8) into a
 * ring buffer, because the hardware RX FIFO is only 8 bytes deep and one
 * video frame at 115200 baud is ~190 bytes.
 *
 * Do NOT use printf()/puts() in this program: the BIOS tty output also
 * goes out through SIO1 and would corrupt the radio link.
 */
#include <sys/types.h>
#include <libetc.h>
#include <libapi.h>
#include "sio.h"

#define SIO_DATA (*(volatile u_char  *)0x1F801050)
#define SIO_STAT (*(volatile u_short *)0x1F801054)
#define SIO_MODE (*(volatile u_short *)0x1F801058)
#define SIO_CTRL (*(volatile u_short *)0x1F80105A)
#define SIO_BAUD (*(volatile u_short *)0x1F80105E)
#define I_STAT   (*(volatile u_long  *)0x1F801070)
#define I_MASK   (*(volatile u_long  *)0x1F801074)

#define ST_TXRDY   0x0001
#define ST_RXRDY   0x0002

#define CT_TXEN    0x0001
#define CT_DTR     0x0002
#define CT_RXEN    0x0004
#define CT_ACK     0x0010
#define CT_RTS     0x0020
#define CT_RESET   0x0040
#define CT_RXIRQ   0x0800

#define RX_SIZE    4096                 /* power of two */
#define RX_MASK    (RX_SIZE - 1)

static volatile u_char  rx_buf[RX_SIZE];
static volatile u_short rx_head, rx_tail;
static u_short ctrl_shadow;
static volatile unsigned long n_rx, n_err;

#define ST_ERRORS  0x0038       /* parity | overrun | framing */

static void sio_isr(void)
{
    while (SIO_STAT & ST_RXRDY) {
        u_char c = SIO_DATA;
        u_short n = (rx_head + 1) & RX_MASK;
        n_rx++;
        if (n != rx_tail) {             /* drop byte if buffer is full */
            rx_buf[rx_head] = c;
            rx_head = n;
        }
    }
    if (SIO_STAT & ST_ERRORS) n_err++;
    SIO_CTRL = ctrl_shadow | CT_ACK;    /* acknowledge the SIO interrupt */
    I_STAT   = ~(1UL << 8);             /* clear IRQ8 pending bit        */
}

void sio_init(unsigned long baud)
{
    rx_head = rx_tail = 0;
    n_rx = n_err = 0;

    SIO_CTRL = CT_RESET;
    SIO_MODE = 0x004E;                  /* x16 clock, 8 data bits, no parity, 1 stop */
    SIO_BAUD = (u_short)((2116800UL + baud / 2) / baud);   /* 33868800/16; 115200 -> 18 */

    /* RTS is asserted so a loop-back RTS->CTS jumper keeps TX enabled. */
    ctrl_shadow = CT_TXEN | CT_DTR | CT_RXEN | CT_RTS | CT_RXIRQ;

    EnterCriticalSection();
    InterruptCallback(8, sio_isr);      /* IRQ8 = SIO */
    ExitCriticalSection();

    I_MASK  |= (1UL << 8);
    SIO_CTRL = ctrl_shadow;
}

int sio_getc(void)
{
    int c;
    if (rx_tail == rx_head) {
        /* Fallback: if the IRQ never fires, read the hardware directly. */
        if (SIO_STAT & ST_RXRDY) {
            c = SIO_DATA;
            n_rx++;
            return c;
        }
        if (SIO_STAT & ST_ERRORS) {
            n_err++;
            SIO_CTRL = ctrl_shadow | CT_ACK;
        }
        return -1;
    }
    c = rx_buf[rx_tail];
    rx_tail = (rx_tail + 1) & RX_MASK;
    return c;
}

void sio_putc(unsigned char c)
{
    unsigned long guard = 200000UL;     /* don't hang if nothing is connected */
    while (!(SIO_STAT & ST_TXRDY) && --guard) ;
    if (guard) SIO_DATA = c;
}

void sio_puts(const char *s)
{
    while (*s) sio_putc((unsigned char)*s++);
}

unsigned long sio_rx_bytes(void) { return n_rx; }
unsigned long sio_errors(void)   { return n_err; }
