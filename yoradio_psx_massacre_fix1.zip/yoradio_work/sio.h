#ifndef SIO_H
#define SIO_H

/* Interrupt-driven SIO1 (rear serial port) driver, 8N1. */
void sio_init(unsigned long baud);
int  sio_getc(void);                 /* next byte, or -1 if none */
void sio_putc(unsigned char c);
void sio_puts(const char *s);
unsigned long sio_rx_bytes(void);   /* total bytes seen (diagnostics) */
unsigned long sio_errors(void);     /* parity/overrun/framing flags seen */

#endif
