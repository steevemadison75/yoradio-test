/*
 * yoRadio PSX - user interface (libgpu + built-in debug font).
 * Screens mirror the web interface: PLAYER / LIST (playlist) / SYSTEM / CONSOLE.
 * All colours are in the palette block below.
 *
 * Layers: ClearOTagR draws the highest index first, so
 * Z_BG is drawn first and Z_GLYPH last.
 */
#include <sys/types.h>
#include <stdio.h>
#include <string.h>
#include <libgte.h>
#include <libgpu.h>
#include <libetc.h>
#include "yoradio.h"
#include "sio.h"
#include "ui.h"
#include "crowd_bg.h"

#define SCR_W 320
#define SCR_H 240
#define OT_LEN 4
#define Z_BG    3
#define Z_PANEL 2
#define Z_FILL  1
#define Z_GLYPH 0
#define PRIM_BYTES 20000

/* ---- palette (r,g,b) ---- */
#define C_BACK   14, 14, 20
#define C_PANEL  30, 30, 40
#define C_ROW0   22, 22, 30
#define C_ROW1   26, 26, 36
#define C_BTN    44, 44, 58
#define C_BAR    50, 50, 62
#define C_ACC     0,120,200
#define C_VOLCOL  255,0,0
#define C_WHITE 255,255,255
#define C_GREEN  60,200, 90
#define C_GREY  110,110,120
#define C_TERM   10, 10, 14
#define C_SD    230,140,  0      /* accent used in SD / mp3 mode */

#define ROWS 9
#define LIST_Y 50

enum { SC_PLAYER, SC_MP3, SC_SYSTEM, SC_CONSOLE, SC_COUNT, SC_LIST };   /* SC_LIST: opened with START, not a tab */
enum { G_PREV, G_PLAY, G_PAUSE, G_STOP, G_NEXT };
enum { K_ACTION, K_NUM, K_CONFIRM, K_EQ };   /* K_EQ: live slider, 'step' = index in yo.eq[] */

typedef struct {
    const char *label;
    const char *cmd;
    int kind, val, lo, hi, step;
} Item;

/* Every entry maps to a command from the wiki list. */
static Item items[] = {
    {"EQ BASS",         "bass",       K_EQ,     0, -16, 16, 0},
    {"EQ MID",          "mid",        K_EQ,     0, -16, 16, 1},
    {"EQ TREBLE",       "treble",     K_EQ,     0, -16, 16, 2},
    {"BALANCE",         "balance",    K_EQ,     0, -16, 16, 3},
    {"SD SHUFFLE",      "shuffle",    K_NUM,    0, 0, 1, 1},
    {"INFO",            "info",       K_ACTION, 0, 0, 0, 0},
    {"VERSION",         "version",    K_ACTION, 0, 0, 0, 0},
    {"DATE / TIME",     "date",       K_ACTION, 0, 0, 0, 0},
    {"FREE HEAP",       "heap",       K_ACTION, 0, 0, 0, 0},
    {"WIFI LIST",       "wifi",       K_ACTION, 0, 0, 0, 0},
    {"WIFI SAVED",      "conn",       K_ACTION, 0, 0, 0, 0},
    {"WIFI SSID",       "ssid",       K_ACTION, 0, 0, 0, 0},
    {"WIFI STATUS / IP", "status",     K_ACTION, 0, 0, 0, 0},
    {"WIFI SIGNAL",     "rssi",       K_ACTION, 0, 0, 0, 0},
    {"DISPLAY ON/OFF",  "dspon",      K_NUM,    1, 0, 1, 1},
    {"BRIGHTNESS",      "dim",        K_NUM,  100, 0, 100, 10},
    {"SLEEP (MIN)",     "sleep",      K_NUM,   30, 1, 240, 5},
    {"SMART START",     "smartstart", K_NUM,    2, 0, 2, 1},
    {"AUDIO DEBUG",     "audioinfo",  K_NUM,    0, 0, 1, 1},
    {"TIMEZONE (H)",    "tzo",        K_NUM,    0, -12, 14, 1},
    {"WIFI RECONNECT",  "disconnect", K_CONFIRM,0, 0, 0, 0},
    {"REBOOT",          "reboot",     K_CONFIRM,0, 0, 0, 0},
    {"RESET SETTINGS",  "reset",      K_CONFIRM,0, 0, 0, 0}
};
#define NITEMS ((int)(sizeof(items) / sizeof(items[0])))

static DISPENV disp[2];
static DRAWENV draw[2];
static u_long  ot[2][OT_LEN];
static char    prim[2][PRIM_BYTES];
static char   *nextpri;
static int     db;
static int     crowd_bg_loaded = 0;

/* Only 3 text streams with small buffers: the Psy-Q font has a limited
   internal pool and overlapping streams garble each other. */
static int f_top, f_main, f_foot;

static int screen, sel_list, top_list, sel_sys, top_sys;
static int list_return;                  /* tab to go back to when the list is closed */
static int tab_dwell, tab_done = 1;      /* switch radio mode after staying on PLAYER/MP3 */
static int sw_t, sw_target;              /* "switching..." banner */
static int marq_t, confirm_t;
static int btn_flash[4];
static int tm_u, tm_d, tm_l, tm_r;
static int list_diag;

/* ------------------------------------------------------------ primitives */

static void *alloc(int n)
{
    void *p;
    if (nextpri + n > prim[db] + PRIM_BYTES) return 0;
    p = nextpri;
    nextpri += n;
    return p;
}

static void rect(int x, int y, int w, int h, int r, int g, int b, int z)
{
    TILE *t = (TILE *)alloc(sizeof(TILE));
    if (!t) return;
    setTile(t);
    setXY0(t, x, y);
    setWH(t, w, h);
    setRGB0(t, r, g, b);
    addPrim(&ot[db][z], t);
}

static void grad(int x, int y, int w, int h,
                 int r0, int g0, int b0, int r1, int g1, int b1, int z)
{
    POLY_G4 *p = (POLY_G4 *)alloc(sizeof(POLY_G4));
    if (!p) return;
    setPolyG4(p);
    setXY4(p, x, y, x + w, y, x, y + h, x + w, y + h);
    setRGB0(p, r0, g0, b0);
    setRGB1(p, r0, g0, b0);
    setRGB2(p, r1, g1, b1);
    setRGB3(p, r1, g1, b1);
    addPrim(&ot[db][z], p);
}

static void tri(int x0, int y0, int x1, int y1, int x2, int y2,
                int r, int g, int b, int z)
{
    POLY_F3 *p = (POLY_F3 *)alloc(sizeof(POLY_F3));
    if (!p) return;
    setPolyF3(p);
    setXY3(p, x0, y0, x1, y1, x2, y2);
    setRGB0(p, r, g, b);
    addPrim(&ot[db][z], p);
}

static void draw_crowd_background(void)
{
    int i;
    if (!crowd_bg_loaded) return;

    /* A 16-bit texture page is 64x256 texels.  Use textured quads
       because SPRT has no tpage field in this Psy-Q GPU structure. */
    for (i = 0; i < 5; i++) {
        POLY_FT4 *p = (POLY_FT4 *)alloc(sizeof(POLY_FT4));
        int x = i * 64;
        if (!p) return;
        setPolyFT4(p);
        setXY4(p, x, 0, x + 63, 0, x, CROWD_BG_HEIGHT - 1,
               x + 63, CROWD_BG_HEIGHT - 1);
        setUV4(p, 0, 0, 63, 0, 0, CROWD_BG_HEIGHT - 1,
               63, CROWD_BG_HEIGHT - 1);
        setClut(p, 0, 0);
        setTPage(p, 0, 0, 640 + i * 64, 0);
        setRGB0(p, 128, 128, 128);
        addPrim(&ot[db][Z_BG], p);
    }
}

static void glyph(int kind, int cx, int cy)
{
    switch (kind) {
    case G_PLAY:
        tri(cx - 4, cy - 6, cx - 4, cy + 6, cx + 6, cy, C_WHITE, Z_GLYPH);
        break;
    case G_PAUSE:
        rect(cx - 5, cy - 6, 4, 12, C_WHITE, Z_GLYPH);
        rect(cx + 1, cy - 6, 4, 12, C_WHITE, Z_GLYPH);
        break;
    case G_STOP:
        rect(cx - 5, cy - 5, 10, 10, C_WHITE, Z_GLYPH);
        break;
    case G_PREV:
        rect(cx - 7, cy - 6, 3, 12, C_WHITE, Z_GLYPH);
        tri(cx + 6, cy - 6, cx + 6, cy + 6, cx - 4, cy, C_WHITE, Z_GLYPH);
        break;
    case G_NEXT:
        rect(cx + 4, cy - 6, 3, 12, C_WHITE, Z_GLYPH);
        tri(cx - 6, cy - 6, cx - 6, cy + 6, cx + 4, cy, C_WHITE, Z_GLYPH);
        break;
    }
}

/* ---------------------------------------------------------------- init */

void ui_init(void)
{
    int i;

    ResetGraph(0);
    SetDefDrawEnv(&draw[0], 0, 0,     SCR_W, SCR_H);
    SetDefDispEnv(&disp[0], 0, SCR_H, SCR_W, SCR_H);
    SetDefDrawEnv(&draw[1], 0, SCR_H, SCR_W, SCR_H);
    SetDefDispEnv(&disp[1], 0, 0,     SCR_W, SCR_H);
    for (i = 0; i < 2; i++) {
        draw[i].isbg = 1;
        setRGB0(&draw[i], 14, 14, 20);   /* = C_BACK; old cpp cannot expand a macro into macro args */
#ifdef PAL_BUILD
        disp[i].screen.y = 8;
        disp[i].screen.h = 240;
#endif
    }
#ifdef PAL_BUILD
    SetVideoMode(MODE_PAL);
#endif

    {
        RECT bgrect;
        setRECT(&bgrect, 640, 0, CROWD_BG_W, CROWD_BG_HEIGHT);
        LoadImage(&bgrect, (u_long *)crowd_bg_pixels);
        DrawSync(0);
        crowd_bg_loaded = 1;
    }

    FntLoad(960, 0);
    f_top  = FntOpen(0, 8,   320, 40,  0, 96);    /* header + tab labels */
    f_main = FntOpen(8, 54,  304, 146, 0, 512);   /* body of every screen */
    f_foot = FntOpen(8, 204, 304, 34,  0, 160);    /* reply line + hints   */

    db = 0;
    ClearOTagR(ot[db], OT_LEN);
    nextpri = prim[db];

    PutDispEnv(&disp[0]);
    PutDrawEnv(&draw[0]);
    SetDispMask(1);
}

/* --------------------------------------------------------------- input */

static int rep(u_long held, u_long edge, u_long mask, int *timer)
{
    if (edge & mask) { *timer = 0; return 1; }
    if (held & mask) {
        (*timer)++;
        if (*timer > 18 && ((*timer - 18) % 3) == 0) return 1;
    } else {
        *timer = 0;
    }
    return 0;
}

static void run_item(Item *it)
{
    char b[48];
    if (it->kind == K_CONFIRM) {
        if (confirm_t > 0) { yo_send(it->cmd); confirm_t = 0; }
        else confirm_t = 150;
        return;
    }
    if (it->kind == K_NUM) sprintf(b, "%s %d", it->cmd, it->val);
    else                   strcpy(b, it->cmd);
    yo_send(b);
}

static void clamp_scroll(int sel, int *top, int n)
{
    if (sel < *top) *top = sel;
    if (sel >= *top + ROWS) *top = sel - ROWS + 1;
    if (*top > n - ROWS) *top = n - ROWS;
    if (*top < 0) *top = 0;
}

static int view_of(int sc) { return (sc == SC_MP3) ? 1 : 0; }   /* MP3 tab = SD view */

/* Switch the radio to web (0) or SD (1) and show the "switching" banner. */
static void want_mode(int m)
{
    yo_mode_set(m);
    sw_target = m;
    sw_t = 360;
    sel_list = top_list = 0;
}

void ui_input(unsigned long held, unsigned long edge)
{
    int up, dn, lf, rt;
    Item *it;

    up = rep(held, edge, PADLup,    &tm_u);
    dn = rep(held, edge, PADLdown,  &tm_d);
    lf = rep(held, edge, PADLleft,  &tm_l);
    rt = rep(held, edge, PADLright, &tm_r);

    if (edge & (PADL1 | PADR1)) {
        if (screen == SC_LIST) {                    /* close the playlist browser */
            screen = list_return;
        } else {
            screen = (screen + ((edge & PADR1) ? 1 : SC_COUNT - 1)) % SC_COUNT;
            tab_dwell = 0;
            tab_done = 0;
        }
        confirm_t = 0;
        return;
    }
    if (confirm_t > 0) confirm_t--;

    /* Staying ~0.75 s on PLAYER / MP3 selects web radio / SD card on the radio.
     * Just passing through a tab with L1/R1 does nothing. */
    if (screen == SC_PLAYER || screen == SC_MP3) {
        if (!tab_done && ++tab_dwell >= 45) {
            tab_done = 1;
            if (yo.mode != view_of(screen)) want_mode(view_of(screen));
        }
    } else {
        tab_dwell = 0;
    }

    switch (screen) {
    case SC_PLAYER:
    case SC_MP3:
        if (edge & PADLleft)  { yo_prev();   btn_flash[0] = 8; }
        if (edge & PADLright) { yo_next();   btn_flash[3] = 8; }
        if (up) yo_vol_set(yo.vol + 2);
        if (dn) yo_vol_set(yo.vol - 2);
        if (edge & PADRdown)  { yo_toggle(); btn_flash[1] = 8; }
        if (edge & PADRright) { yo_start();  btn_flash[1] = 8; }
        if (edge & PADRleft)  { yo_stop();   btn_flash[2] = 8; }
        if (edge & PADRup)    yo_info();
        if (edge & PADselect) want_mode(view_of(screen));      /* retry / force this tab's mode */
        if (edge & PADstart) {                                  /* playlist browser */
            list_return = screen;
            screen = SC_LIST;
            if (yo.nstations == 0) yo_list();
        }
        break;

    case SC_LIST:
        if (yo.nstations > 0) {
            if (up) sel_list--;
            if (dn) sel_list++;
            if (lf) sel_list -= ROWS;
            if (rt) sel_list += ROWS;
            if (edge & PADL2) sel_list -= 50;
            if (edge & PADR2) sel_list += 50;
            if (sel_list < 0) sel_list = 0;
            if (sel_list > yo.nstations - 1) sel_list = yo.nstations - 1;
            clamp_scroll(sel_list, &top_list, yo.nstations);
            if (edge & PADRdown) yo_play_station(sel_list + YO_LIST_BASE);
        }
        if (edge & PADRup) yo_list();
        if (edge & PADselect) list_diag = !list_diag;
        if (edge & (PADstart | PADRright)) screen = list_return;   /* back to the player */
        break;

    case SC_SYSTEM:
        if (up || dn) confirm_t = 0;
        if (up && sel_sys > 0) sel_sys--;
        if (dn && sel_sys < NITEMS - 1) sel_sys++;
        clamp_scroll(sel_sys, &top_sys, NITEMS);
        it = &items[sel_sys];
        if (it->kind == K_NUM) {
            if (lf && it->val - it->step >= it->lo) it->val -= it->step;
            if (rt && it->val + it->step <= it->hi) it->val += it->step;
        }
        if (it->kind == K_EQ) {                         /* applied live, X = back to 0 */
            if (lf) yo_eq_set(it->step, yo.eq[it->step] - 1);
            if (rt) yo_eq_set(it->step, yo.eq[it->step] + 1);
            if (edge & PADRdown) yo_eq_set(it->step, 0);
        } else if (edge & PADRdown) {
            run_item(it);
        }
        break;

    case SC_CONSOLE:
        if (edge & PADRup)   yo_info();
        if (edge & PADRleft) yo_log_clear();
        break;
    }
}

/* ------------------------------------------------------------- drawing */

static void marquee(char *out, const char *s, int w)
{
    int len = (int)strlen(s), cyc, off, i, k;
    if (len <= w) { strcpy(out, s); return; }
    cyc = len + 4;
    off = (marq_t / 8) % cyc;
    for (i = 0; i < w; i++) {
        k = (off + i) % cyc;
        out[i] = (k < len) ? s[k] : ' ';
    }
    out[w] = 0;
}

static void chrome(void)
{
    char hb[48], ipbuf[20];
    int i;

    /* Original La Radio Massacre artwork is the full-screen background. */
    draw_crowd_background();

    /* header */
  //grad(0, 0, SCR_W, 26, 46, 46, 60, 24, 24, 32, Z_BG);
    grad(0, 0, SCR_W, 26, 60, 0, 100, 35, 0, 50, Z_BG);
    rect(0, 26, SCR_W, 2, C_ACC, Z_PANEL);
    if (yo.since_rx < 6) rect(6, 8, 6, 8, C_GREEN, Z_FILL);
    else                 rect(6, 8, 6, 8, C_GREY,  Z_FILL);
    /* IP is only shown while the radio is answering (linked), else 0.0.0.0 */
    if (!(yo.rx_lines > 0 && yo.since_rx < 3600)) strcpy(ipbuf, "666.666.666.666");   /* no radio */
    else if (yo.ip[0])                           strcpy(ipbuf, yo.ip);        /* reported by the radio */
    else                                         strcpy(ipbuf, "UNKNOWN");    /* linked, no IP seen yet */
    sprintf(hb, "~c880yoRadio 4 PSX V6~c888   IP %s", ipbuf);
    FntPrint(f_top, "  %s\n\n\n  PLAYER     MP3      SYSTEM   CONSOLE", hb);

    /* tabs */
    rect(0, 28, SCR_W, 16, 20, 20, 26, Z_BG);
    for (i = 0; i < SC_COUNT; i++) {
        if (i == ((screen == SC_LIST) ? list_return : screen)) {
            if (view_of(i)) rect(i * 80 + 1, 28, 78, 16, C_SD, Z_PANEL);    /* MP3 tab = amber */
            else            rect(i * 80 + 1, 28, 78, 16, C_ACC, Z_PANEL);
        }
        else             rect(i * 80 + 1, 28, 78, 16, 28, 28, 36, Z_PANEL);
    }

    /* footer */
  //grad(0, 200, SCR_W, 40, 28, 28, 36, 16, 16, 22, Z_BG);
    grad(0, 200, SCR_W, 40, 60, 0, 100, 35, 0, 50, Z_BG);
}

static void foot(const char *hint)
{
    /* Footer = 2 reply lines (8 px apart), a gap, then the key hint. */
    char full[80], l1[40], l2[40];
    if (confirm_t > 0)   strcpy(full, "> CONFIRM: PRESS X AGAIN");
    else if (yo.last[0]) sprintf(full, "> %.72s", yo.last);
    else                 strcpy(full, "> READY");
    sprintf(l1, "%.37s", full);                     /* 38 cols would wrap */
    if (strlen(full) > 37) sprintf(l2, "%.37s", full + 37);
    else                   l2[0] = 0;
    FntPrint(f_foot, "%s\n%s\n\n%s", l1, l2, hint);
}

static void draw_player(int view)       /* view 0 = web radio, 1 = SD / mp3 */
{
    char a[48], b[48], m[48], v[48], lab[48];
    int i, w, x, glyph_k, total, w2;
    const char *noun = view ? "SD TRACK" : "STATION";
    int mismatch = (yo.mode >= 0 && yo.mode != view);        /* radio is in the other mode */

    if (view) {
    rect(8, 50, 2, 40, C_SD, Z_FILL);              /* amber = SD / mp3 mode */
    rect(310, 50, 2, 40, C_SD, Z_FILL);
    rect(8, 90, 304, 2, C_SD, Z_FILL);
    rect(8, 50, 304, 2, C_SD, Z_FILL);
    rect(8, 96, 2, 44, C_SD, Z_FILL);
    rect(310, 96, 2, 44, C_SD, Z_FILL);
    rect(8, 140, 304, 2, C_SD, Z_FILL);
    rect(8, 96, 304, 2, C_SD, Z_FILL);
    rect(8, 50, 304, 40, C_PANEL, Z_PANEL);
    rect(8, 96, 304, 44, C_PANEL, Z_PANEL);
}
else 
    rect(8, 50, 304, 40, C_PANEL, Z_PANEL);
    rect(8, 50, 2, 40, C_ACC, Z_FILL);
    rect(310, 50, 2, 40, C_ACC, Z_FILL);
    rect(8, 90, 304, 2, C_ACC, Z_FILL);
    rect(8, 50, 304, 2, C_ACC, Z_FILL);


    rect(8, 96, 304, 44, C_PANEL, Z_PANEL);
    rect(8, 96, 2, 44, C_ACC, Z_FILL);
    rect(310, 96, 2, 44, C_ACC, Z_FILL);
    rect(8, 140, 304, 2, C_ACC, Z_FILL);
    rect(8, 96, 304, 2, C_ACC, Z_FILL);

    total = (yo.nstations > 0) ? yo.nstations : yo.count;
    if (yo.station > 0 && !mismatch) {
        if (total > 0) sprintf(a, "%s %d / %d", noun, yo.station, total);
        else           sprintf(a, "%s %d", noun, yo.station);
    } else {
        sprintf(a, "%s --", noun);
    }
    if (mismatch && sw_t > 0) sprintf(b, "%.36s", view ? "SWITCHING TO SD CARD..." : "SWITCHING TO RADIO...");
    else if (mismatch)        sprintf(b, "%.36s", view ? "SD CARD NOT ACTIVE - PRESS SELECT" : "RADIO NOT ACTIVE - PRESS SELECT");
    else                      sprintf(b, "%.36s", yo.name[0] ? yo.name : "(WAITING FOR RADIO)");

    if (yo.playing) rect(296, 58, 8, 8, C_GREEN, Z_FILL);
    else            rect(296, 58, 8, 8, C_GREY,  Z_FILL);

    marquee(m, (!mismatch && yo.title[0]) ? yo.title : "-", 36);

    /* volume */
    rect( 15, 149, 226,  1, C_WHITE, Z_PANEL);
    rect( 16, 150, 224, 12, C_BAR,   Z_PANEL);
    rect( 15, 162, 226,  1, C_WHITE, Z_PANEL);
    rect( 15, 149,   1, 14, C_WHITE, Z_PANEL);
    rect(240, 149,   1, 14, C_WHITE, Z_PANEL);

    w = yo.vol * 224 / YO_VOL_MAX;
    if (w < 0) w = 0;
    if (w > 224) w = 224;
    if (w > 0) rect(16, 150, w, 12, C_VOLCOL, Z_FILL);
    /* all player text in one stream: line n is at y = 54 + 8*n */
    sprintf(v, "                              VOL %3d", yo.vol);
    strcpy(lab, "NOW PLAYING");
    if (view && !mismatch && yo.t_cur >= 0) {                     /* SD: elapsed / length */
        if (yo.t_dur > 0) {
            sprintf(lab, "NOW PLAYING        %02d:%02d / %02d:%02d",
                    yo.t_cur / 60, yo.t_cur % 60, yo.t_dur / 60, yo.t_dur % 60);
            w2 = yo.t_cur * 288 / yo.t_dur;
            if (w2 > 288) w2 = 288;
            rect(16, 134, 288, 3, C_BAR, Z_FILL);
            if (w2 > 0) rect(16, 134, w2, 3, C_SD, Z_GLYPH);
        } else {
            sprintf(lab, "NOW PLAYING        %02d:%02d", yo.t_cur / 60, yo.t_cur % 60);
        }
    }
    FntPrint(f_main, " %s\n\n %s\n\n\n\n %s\n\n %s\n\n\n\n%s", a, b, lab, m, v);

    /* transport buttons: prev, play/pause, stop, next */
    for (i = 0; i < 4; i++) {
        x = 44 + i * 60;
        if (btn_flash[i] > 0) { btn_flash[i]--; rect(x, 168, 52, 26, C_ACC, Z_FILL); }
        else                  rect(x, 168, 52, 26, C_BTN, Z_FILL);
        if (i == 0)      glyph_k = G_PREV;
        else if (i == 1) glyph_k = yo.playing ? G_PAUSE : G_PLAY;
        else if (i == 2) glyph_k = G_STOP;
        else             glyph_k = G_NEXT;
        glyph(glyph_k, x + 26, 181);
    }
    foot("L/R STN U/D VOL X TOG SQ STP ST LIST");
}

static void scrollbar(int top, int n)
{
    int h;
    if (n <= ROWS) return;
    rect(314, LIST_Y, 4, ROWS * 16, 40, 40, 52, Z_BG);
    h = ROWS * 16 * ROWS / n;
    if (h < 8) h = 8;
    rect(314, LIST_Y + (ROWS * 16 - h) * top / (n - ROWS), 4, h, C_ACC, Z_PANEL);
}

static void draw_list(void)
{
    char b[48], c[48];
    int i, idx, y;

    if (list_diag) {                    /* SELECT: raw view of what the radio sent */
        sprintf(b, "GOT %d MISS %d BAD %d TRY %d", yo.list_got,
                yo.list_missing, yo.list_bad, yo.list_tries);
        sprintf(c, "STATIONS %d  NUMBER WRAPS %d", yo.nstations, yo.list_wraps);
        FntPrint(f_main, "LIST DIAGNOSTIC (SELECT=BACK)\n\n%s\n%s\n\n", b, c);
        for (i = 0; i < yo.lsample_n; i++) {
            sprintf(b, "%.37s", yo.lsample[i]);
            if (strlen(yo.lsample[i]) > 37) sprintf(c, "%.37s", yo.lsample[i] + 37);
            else c[0] = 0;
            FntPrint(f_main, "%s\n%s\n\n", b, c);
        }
        foot("SELECT BACK TRI RELOAD");
        return;
    }
    if (yo.nstations <= 0) {
        if (yo.list_wait > 0) FntPrint(f_main, "\n  LOADING PLAYLIST...\n");
        else FntPrint(f_main, "\n  NO PLAYLIST LOADED YET\n\n  PRESS TRIANGLE TO REQUEST IT\n");
        foot("L1/R1 TABS TRI REFRESH");
        return;
    }
    if (yo.list_wait > 0)
        sprintf(yo.last, "LOADING PLAYLIST... %d", yo.list_got);
    for (i = 0; i < ROWS; i++) {
        idx = top_list + i;
        if (idx >= yo.nstations) break;
        y = LIST_Y + i * 16;
        if (idx == sel_list)  rect(8, y, 300, 15, C_ACC, Z_PANEL);
        else if (i & 1)       rect(8, y, 300, 15, C_ROW1, Z_BG);
        else                  rect(8, y, 300, 15, C_ROW0, Z_BG);
        sprintf(b, "%s%3d %.31s", (idx + YO_LIST_BASE == yo.station) ? ">" : " ",
                idx + YO_LIST_BASE, yo.list[idx]);
        FntPrint(f_main, "%s\n\n", b);
    }
    scrollbar(top_list, yo.nstations);
    foot("U/D L/R PAGE L2R2 JUMP X PLAY ST BACK");
}

static void draw_system(void)
{
    char b[56], v[16];
    int i, idx, y;
    Item *it;

    for (i = 0; i < ROWS; i++) {
        idx = top_sys + i;
        if (idx >= NITEMS) break;
        it = &items[idx];
        y = LIST_Y + i * 16;
        if (idx == sel_sys)  rect(8, y, 300, 15, C_ACC, Z_PANEL);
        else if (i & 1)      rect(8, y, 300, 15, C_ROW1, Z_BG);
        else                 rect(8, y, 300, 15, C_ROW0, Z_BG);
        if (it->kind == K_EQ) {
            int e = yo.eq[it->step];
            if (e > 0) sprintf(v, "< +%d >", e);
            else       sprintf(v, "< %d >", e);
        } else if (it->kind == K_NUM) {
            sprintf(v, "< %d >", it->val);
        } else {
            v[0] = 0;
        }
        sprintf(b, " %-18s %s", it->label, v);
        FntPrint(f_main, "%s\n\n", b);
        if (it->kind == K_EQ) {                          /* small -16..+16 slider */
            int e = yo.eq[it->step];
            rect(232, y + 6, 72, 3, C_BAR, Z_FILL);
            rect(267, y + 4, 2, 7, C_GREY, Z_FILL);
            rect(266 + e * 36 / 16, y + 4, 4, 7, C_WHITE, Z_GLYPH);
        }
    }
    scrollbar(top_sys, NITEMS);
    foot("U/D SELECT L/R ADJUST X RUN/ZERO");
}

static void draw_console(void)
{
    int k, idx;
    char a[48];
    rect(8, 50, 304, 148, C_TERM, Z_PANEL);
    sprintf(a, "RX %d ERR %d LINES %d", (int)sio_rx_bytes(), (int)sio_errors(), yo.rx_lines);
    FntPrint(f_main, "%s\n", a);
    sprintf(a, "%.37s", yo.raw + 39);
    FntPrint(f_main, "%s\n", a);
    for (k = 7; k < YO_LOG_LINES; k++) {
        idx = (yo.log_head + k) % YO_LOG_LINES;
        sprintf(a, "%.37s", yo.log[idx]);
        FntPrint(f_main, "%s\n", a);
    }
    foot("TRI INFO SQ CLEAR L1/R1 TABS");
}

void ui_draw(void)
{
    marq_t++;
    if (sw_t > 0 && (--sw_t, yo.mode == sw_target)) sw_t = 0;
    chrome();
    switch (screen) {
    case SC_PLAYER:  draw_player(0); break;
    case SC_MP3:     draw_player(1); break;
    case SC_LIST:    draw_list();    break;
    case SC_SYSTEM:  draw_system();  break;
    case SC_CONSOLE: draw_console(); break;
    }

    DrawSync(0);
    VSync(0);
    PutDispEnv(&disp[db]);
    PutDrawEnv(&draw[db]);
    DrawOTag(ot[db] + OT_LEN - 1);
    FntFlush(f_top);
    FntFlush(f_main);
    FntFlush(f_foot);

    db = !db;
    ClearOTagR(ot[db], OT_LEN);
    nextpri = prim[db];
}
