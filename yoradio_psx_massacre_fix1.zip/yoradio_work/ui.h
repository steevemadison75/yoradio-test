#ifndef UI_H
#define UI_H
void ui_init(void);
void ui_input(unsigned long held, unsigned long edge);
void ui_draw(void);
#endif
