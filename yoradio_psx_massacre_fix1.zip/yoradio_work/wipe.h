/*
 * wipe.h - screen wipe transitions for the BIOS 640x480 framebuffer
 *
 *   Wipe_Box()   black box wipe (the classic one)
 *   Wipe_Rain()  matrix rain wipe (call Wipe_LoadFont() first)
 *
 *   Wipe_BoxLR() black box wipe, left to right (instead of top to bottom)
 *   Wipe_Fade()  smooth fade of the whole screen to black
 *   Wipe_Pacman() a row of Pac-Men eat the screen
 *   Wipe_PacmanChase() same, but a ghost chases every Pac-Man
 *
 *   Wipe_Auto()  picks one of the above from the pad buttons held at boot
 *                (nothing held = no wipe, normal boot)
 *
 * Call after ResetGraph(3) and BEFORE you set up your own draw/disp envs.
 * Both draw straight onto the picture that is already on screen, so the
 * old screen is wiped in place, leaving the whole 640x480 area black.
 *
 * Each wipe also has Init/Step functions if you want to run the loop
 * yourself (e.g. to poll the pad between frames):
 *
 *     Wipe_RainInit();
 *     while (Wipe_RainStep()) { ...your code... }
 */
#ifndef WIPE_H
#define WIPE_H

#include <sys/types.h>

/* ---- font (needed by the rain wipe, and handy for your own rain) ---- */

/* number of glyphs in the built-in matrix font (8x8 glyphs, 16 per row) */
#define MATRIX_FONT_GLYPHS  50

/*
 * Load the built-in matrix font (the TIM data lives inside wipe.c).
 * It is placed at VRAM x=640 (outside the 640x480 area the wipe clears).
 * Call it once, after ResetGraph(3). After that Wipe_FontTPage() and
 * Wipe_FontClut() give you the ids to draw the font yourself.
 */
void    Wipe_LoadFont(void);
u_short Wipe_FontTPage(void);   /* texture page of the loaded font */
u_short Wipe_FontClut(void);    /* CLUT of the loaded font         */

/* ---- box wipe ---- */

void Wipe_SetBoxColor(u_char r, u_char g, u_char b);  /* default: black */
void Wipe_BoxInit(void);
int  Wipe_BoxStep(void);        /* one frame; returns 1 while running, 0 when done */
void Wipe_Box(void);            /* runs the whole wipe (blocking) */

/* ---- rain wipe ---- */

void Wipe_RainInit(void);
int  Wipe_RainStep(void);       /* one frame; returns 1 while running, 0 when done */
void Wipe_Rain(void);           /* runs the whole wipe (blocking) */

/* ---- box wipe, left to right ---- */

void Wipe_BoxLRInit(void);
int  Wipe_BoxLRStep(void);      /* one frame; returns 1 while running, 0 when done */
void Wipe_BoxLR(void);          /* runs the whole wipe (blocking) */
                                /* uses the colour from Wipe_SetBoxColor() */

/* ---- fade to black ---- */

void Wipe_SetFadeSpeed(u_char step);  /* brightness removed per frame, 8..255 (default 8 = ~0.5 s) */
void Wipe_FadeInit(void);
int  Wipe_FadeStep(void);       /* one frame; returns 1 while running, 0 when done */
void Wipe_Fade(void);           /* runs the whole fade (blocking) */

/* ---- pac-man wipe ---- */

void Wipe_PacmanInit(void);
int  Wipe_PacmanStep(void);     /* one frame; returns 1 while running, 0 when done */
void Wipe_Pacman(void);         /* runs the whole wipe (blocking) */

/* ---- pac-man wipe, chased by ghosts ---- */

void Wipe_PacmanChaseInit(void);
int  Wipe_PacmanChaseStep(void); /* one frame; returns 1 while running, 0 when done */
void Wipe_PacmanChase(void);    /* runs the whole wipe (blocking) */

/* ---- boot-time selection ---- */

/*
 * Reads the pad and runs a wipe depending on what is held:
 *   Select+Start  PacmanChase      L1+R1  Fade
 *   L1  Box       R1  BoxLR        R2  Pacman       L2  Rain
 * Nothing held: does nothing (normal boot). Returns 1 if a wipe ran, 0 otherwise.
 * Call after ResetGraph(3) + VSync(0).
 */
int Wipe_Auto(void);

#endif /* WIPE_H */
