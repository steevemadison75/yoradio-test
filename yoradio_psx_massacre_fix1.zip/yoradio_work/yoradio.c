/*
 * yoRadio UART/telnet command layer.  The command set is the one from the
 * wiki page "List of available commands (UART telnet GET POST)".
 *
 * Replies are parsed in KaRadio style ("##CLI.VOL#: 100").  All reply
 * parsing lives in handle_line(); if your firmware prints something
 * slightly different, that is the only function to adjust.
 */
#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>
#include "sio.h"
#include "yoradio.h"

YoState yo;

static char line[160];
static int  quiet;       /* frames during which automatic info replies stay out of the footer */
static int  sd_poll;
static int  was_lost;    /* link dropped: re-ask the IP when data returns */
static int  list_prev;   /* last station number printed by the radio */
static int  list_off;    /* +256 for every wrap of the radio's 8-bit counter */
static int  keepalive;
static int  llen;

/* ASCII-only copy (the PSX debug font has no UTF-8). */
static void copy_clean(char *dst, const char *src, int max)
{
    int n = 0;
    unsigned char c;
    while ((c = (unsigned char)*src++) != 0 && n < max - 1) {
        if (c >= 0xC0)       dst[n++] = '?';   /* UTF-8 lead byte  */
        else if (c >= 0x80)  continue;         /* continuation     */
        else if (c >= 32 && c < 127) dst[n++] = (char)c;
    }
    dst[n] = 0;
}

static void log_add(const char *s)
{
    copy_clean(yo.log[yo.log_head], s, YO_LOG_COLS + 1);
    yo.log_head = (yo.log_head + 1) % YO_LOG_LINES;
}

void yo_log_clear(void)
{
    memset(yo.log, 0, sizeof(yo.log));
    yo.log_head = 0;
}

/* Remove the ", http://..." part that follows the station name. */
static void cut_url(char *t)
{
    char *p = strstr(t, ", http");
    int l;
    if (!p) p = strstr(t, ",http");
    if (!p) {
        p = strrchr(t, ',');
        if (p && !strchr(p, '/') && !strchr(p, '.') && !strchr(p, ':')) p = 0;
    }
    if (p) *p = 0;
    l = (int)strlen(t);
    while (l > 0 && t[l - 1] == ' ') t[--l] = 0;
}

/* Accepts "12: Name, url", "12, Name, url", "12 Name" ... */
static int list_entry(const char *tag, const char *pl)
{
    char tmp[128];
    int n;
    while (*pl == ' ' || *pl == ':') pl++;
    if (!isdigit((unsigned char)*pl)) return 0;
    n = atoi(pl);
    /* yoRadio prints the number as 8 bits (... 254, 255, 0, 1 ...), so with more
     * than 255 stations the numbers wrap.  A big drop means a wrap: rebuild the
     * real index by adding 256 each time. */
    if (n < list_prev - 128) { list_off += 256; yo.list_wraps++; }
    list_prev = n;
    n += list_off;
    while (isdigit((unsigned char)*pl)) pl++;
    while (*pl == ' ' || *pl == ':' || *pl == ',' || *pl == '.' || *pl == ')') pl++;
    n -= YO_LIST_BASE;
    if (n < 0 || n >= YO_MAX_STATIONS) return 0;
    copy_clean(tmp, pl, sizeof(tmp));
    cut_url(tmp);
    if (!yo.list[n][0] && tmp[0]) yo.list_got++;
    yo.list_idle = 0;
    if (yo.list_wait > 0) yo.list_wait = 900;
    strncpy(yo.list[n], tmp, YO_NAME_LEN - 1);
    yo.list[n][YO_NAME_LEN - 1] = 0;
    if (n + 1 > yo.nstations) yo.nstations = n + 1;
    (void)tag;
    return 1;
}

/* Forget the playlist (play mode changed: web <-> SD). */
static void clear_list(void)
{
    memset(yo.list, 0, sizeof(yo.list));
    yo.nstations = 0;
    yo.count = 0;
    yo.list_got = yo.list_missing = yo.list_tries = 0;
    yo.list_bad = yo.lsample_n = 0;
    yo.list_wait = 0;
    yo.list_wraps = 0;
    list_prev = list_off = 0;
}

/* The radio's current-station number is also 8 bit: find the real one by name. */
static void fix_station(void)
{
    int k, low = yo.station & 255;
    if (!yo.name[0] || yo.nstations <= 0) return;
    for (k = 0; k < yo.nstations; k++) {
        if (((k + YO_LIST_BASE) & 255) == low && !strcmp(yo.list[k], yo.name)) {
            yo.station = k + YO_LIST_BASE;
            return;
        }
    }
}

static void sample_add(const char *s)
{
    if (yo.lsample_n < 3) {
        copy_clean(yo.lsample[yo.lsample_n], s, 75);
        yo.lsample_n++;
    }
}

/* ---- device IP: the wiki has no "ip" command, so pick it out of any
 * reply that mentions "IP" (word) and contains a dotted quad. */
static int word_ip(const char *s)
{
    int i;
    for (i = 0; s[i]; i++) {
        if ((s[i] == 'I' || s[i] == 'i') && (s[i + 1] == 'P' || s[i + 1] == 'p') &&
            (i == 0 || !isalpha((unsigned char)s[i - 1])) &&
            !isalpha((unsigned char)s[i + 2])) return 1;
    }
    return 0;
}

static int parse_ip(const char *p, char *out)
{
    int o[4], i, n;
    for (i = 0; i < 4; i++) {
        if (!isdigit((unsigned char)*p)) return 0;
        n = 0;
        while (isdigit((unsigned char)*p)) { n = n * 10 + (*p - '0'); if (n > 255) return 0; p++; }
        o[i] = n;
        if (i < 3) { if (*p != '.') return 0; p++; }
    }
    sprintf(out, "%d.%d.%d.%d", o[0], o[1], o[2], o[3]);
    return 1;
}

static void scan_ip(const char *s, int loose)
{
    const char *p;
    char ip[20];
    char up[160];
    int i, last;
    if (strstr(s, "://") || (!loose && !word_ip(s))) return;
    for (i = 0; s[i] && i < 159; i++) up[i] = (char)toupper((unsigned char)s[i]);
    up[i] = 0;
    /* skip lines about the router / DNS rather than the radio itself */
    if (strstr(up, "GW") || strstr(up, "GATE") || strstr(up, "DNS") ||
        strstr(up, "ROUTER") || strstr(up, "MASK")) return;
    for (p = s; *p; p++) {
        if (isdigit((unsigned char)*p) && (p == s || (!isdigit((unsigned char)p[-1]) && p[-1] != '.'))) {
            if (!parse_ip(p, ip)) continue;
            if (strncmp(ip, "192.168.", 8) != 0) continue;       /* LAN addresses only */
            last = atoi(strrchr(ip, '.') + 1);
            if (last == 1 || last == 254) continue;               /* looks like the router */
            strcpy(yo.ip, ip);
            return;
        }
    }
}

static void handle_line(const char *s)
{
    char tag[28];
    const char *p, *q, *pl;
    int n, i;

    log_add(s);
    yo.since_rx = 0;
    yo.rx_lines++;

    if (was_lost) { was_lost = 0; yo_send("status"); }   /* new/returning radio */
    if (strstr(s, "SD Not Found")) {      /* mode 1 refused: no card */
        yo.mode = 0;
        strcpy(yo.last, "SD CARD NOT FOUND");
    }
    scan_ip(s, 0);
    p = strchr(s, '#');
    if (!p) {                           /* untagged line: maybe a list entry */
        if (yo.list_wait > 0) {
            sample_add(s);
            if (!list_entry("", s)) yo.list_bad++;
        }
        return;
    }
    while (*p == '#') p++;
    q = strchr(p, '#');
    if (!q) return;
    n = (int)(q - p);
    if (n > (int)sizeof(tag) - 1) n = (int)sizeof(tag) - 1;
    for (i = 0; i < n; i++) tag[i] = (char)toupper((unsigned char)p[i]);
    tag[n] = 0;

    if (!strncmp(tag, "WIFI.", 5) || !strncmp(tag, "SYS.", 4)) scan_ip(s, 1);

    pl = q + 1;
    while (*pl == '#') pl++;
    while (*pl == ':' || *pl == ' ') pl++;

    if (!strcmp(tag, "CLI.VOL")) {
        if (yo.vol_lock == 0) {
            yo.vol = atoi(pl);
            if (yo.vol > YO_VOL_MAX) yo.vol = YO_VOL_MAX;
        }
    } else if (!strcmp(tag, "CLI.META")) {
        copy_clean(yo.title, pl, YO_TITLE_LEN);
    } else if (!strcmp(tag, "CLI.NAMESET")) {
        yo.station = atoi(pl);
        while (isdigit((unsigned char)*pl)) pl++;
        while (*pl == ' ') pl++;
        {   /* payload looks like "17 17:NAME": drop the repeated "17:" */
            const char *q2 = pl;
            while (isdigit((unsigned char)*q2)) q2++;
            if (q2 != pl && *q2 == ':') {
                pl = q2 + 1;
                while (*pl == ' ') pl++;
            }
        }
        copy_clean(yo.name, pl, YO_NAME_LEN);
        fix_station();
    } else if (!strcmp(tag, "CLI.PLAYING")) {
        yo.playing = 1;
    } else if (!strcmp(tag, "CLI.STOPPED")) {
        yo.playing = 0;
    } else if (!strcmp(tag, "CLI.MODE")) {
        int m = atoi(pl);
        if (yo.mode >= 0 && yo.mode != m) clear_list();      /* other playlist now */
        yo.mode = m;
        if (m != 1) yo.t_cur = yo.t_dur = -1;
    } else if (!strcmp(tag, "CLI.EQ")) {                      /* "bass mid treble balance" */
        int k;
        for (k = 0; k < 4; k++) {
            while (*pl == ' ') pl++;
            if (!*pl) break;
            yo.eq[k] = atoi(pl);
            while (*pl && *pl != ' ') pl++;
        }
        yo.eq_known = 1;
    } else if (!strcmp(tag, "CLI.COUNT")) {
        yo.count = atoi(pl);
    } else if (!strcmp(tag, "CLI.TIME")) {                    /* "cur/dur" in seconds */
        const char *sl = strchr(pl, '/');
        yo.t_cur = atoi(pl);
        yo.t_dur = sl ? atoi(sl + 1) : -1;
        yo.t_sub = 0;
    } else if (!strcmp(tag, "SYS.IP")) {          /* sent by the patched firmware in "info" */
        char ipb[20];
        if (parse_ip(pl, ipb)) strcpy(yo.ip, ipb);
    } else if (!strncmp(tag, "CLI.LIST", 8)) {   /* LIST, LISTNUM, LISTINFO ... */
        if (isdigit((unsigned char)*pl)) sample_add(s);
        if (!list_entry(tag, pl)) yo.list_bad++;
    } else if (yo.list_wait > 0 && isdigit((unsigned char)*pl)) {
        sample_add(s);
        if (!list_entry(tag, pl)) yo.list_bad++;
    } else {
        int noisy = !strncmp(tag, "AUDIO", 5) || !strcmp(tag, "CLI.INFO") ||
                    (quiet > 0 && !strcmp(tag, "SYS.DATE"));
        if (yo.list_wait > 0 && !noisy) sample_add(s);
        if (!noisy) copy_clean(yo.last, s, 76);
    }
}

void yo_send(const char *cmd)
{
    sio_puts(cmd);
    sio_putc('\n');
}

/* Re-ask for the list without clearing what we already have (fills gaps). */
static void list_retry(void)
{
    yo.list_tries++;
    list_prev = list_off = 0;
    yo.list_wraps = 0;
    yo.list_wait = 900;
    yo.list_idle = 0;
    yo_send("list");
}

/* Called when the list has stopped arriving: count gaps, retry if needed. */
static void list_check(void)
{
    int i, miss = 0;
    if (yo.count > yo.nstations && yo.count <= YO_MAX_STATIONS) yo.nstations = yo.count;
    for (i = 0; i < yo.nstations; i++) if (!yo.list[i][0]) miss++;
    yo.list_missing = miss;
    if (miss > 0 && yo.list_tries < 3) {
        list_retry();
        return;
    }
    yo.list_wait = 0;
    fix_station();
    sprintf(yo.last, "LIST: %d LOADED, %d MISSING", yo.list_got, miss);
}

/* info request that must not flood the footer with its date/status lines */
static void auto_info(void)
{
    quiet = 45;
    yo_info();
}

void yo_poll(void)
{
    int c;
    if (yo.vol_lock > 0) yo.vol_lock--;
    if (quiet > 0) quiet--;
    if (yo.info_at > 0 && --yo.info_at == 0) auto_info();
    if (yo.mode == 1 && yo.playing) {
        if (yo.t_cur >= 0 && yo.t_dur > 0 && ++yo.t_sub >= 60) {   /* tick the clock */
            yo.t_sub = 0;
            if (yo.t_cur < yo.t_dur) yo.t_cur++;
        }
        if (++sd_poll >= 300) { sd_poll = 0; auto_info(); }          /* resync every ~5 s */
    }
    if (yo.list_wait > 0) {
        yo.list_wait--;
        if (yo.nstations > 0 && ++yo.list_idle > 150)   /* ~2.5 s of silence = done */
            list_check();
    }
    if (yo.since_rx > 3600) { was_lost = 1; yo.ip[0] = 0; }   /* radio gone: forget its IP */
    if (++keepalive >= 1800) {          /* every ~30 s: keeps the link status fresh */
        keepalive = 0;
        auto_info();
        if (!yo.ip[0]) yo_send("status");
    }
    if (yo.since_rx < 100000) yo.since_rx++;

    while ((c = sio_getc()) >= 0) {
        memmove(yo.raw, yo.raw + 1, 75);
        yo.raw[75] = (c >= 32 && c < 127) ? (char)c : '.';
        if (c == '\n') {
            line[llen] = 0;
            if (llen) handle_line(line);
            llen = 0;
        } else if (c != '\r' && llen < (int)sizeof(line) - 1) {
            line[llen++] = (char)c;
        }
    }
}

void yo_init(unsigned long baud)
{
    memset(&yo, 0, sizeof(yo));
    llen = 0;
    yo.mode = -1;
    yo.t_cur = yo.t_dur = -1;
    memset(yo.raw, ' ', 76);
    yo.raw[76] = 0;
    sio_init(baud);
    yo_send("");            /* flush any half-typed line on the ESP32 side */
    yo_info();
    yo_send("vol");
    yo_send("status");      /* may reveal the IP address */
}

void yo_prev(void)   { yo_send("prev"); }
void yo_next(void)   { yo_send("next"); }
void yo_toggle(void) { yo_send("toggle"); }
void yo_stop(void)   { yo_send("stop"); }
void yo_start(void)  { yo_send("start"); }
void yo_info(void)   { yo_send("info"); }
void yo_eq_set(int which, int v)
{
    static const char *nm[4] = { "bass", "mid", "treble", "balance" };
    char b[24];
    if (which < 0 || which > 3) return;
    if (v < -16) v = -16;
    if (v >  16) v =  16;
    yo.eq[which] = v;
    sprintf(b, "%s %d", nm[which], v);
    yo_send(b);
}

void yo_mode_set(int m)
{
    char b[16];
    clear_list();
    sprintf(b, "mode %d", m);
    yo_send(b);
    yo.info_at = 240;               /* ask again in ~4 s: the radio may need time */
}

void yo_mode_toggle(void)
{
    if (yo.mode == 1)      yo_mode_set(0);
    else if (yo.mode == 0) yo_mode_set(1);
    else {                          /* unpatched firmware: mode unknown, let the radio toggle */
        clear_list();
        yo_send("mode 2");
        yo.info_at = 240;
    }
}

void yo_list(void)
{
    memset(yo.list, 0, sizeof(yo.list));
    yo.nstations = 0;
    yo.list_got = yo.list_missing = yo.list_tries = 0;
    yo.list_bad = yo.lsample_n = 0;
    list_prev = list_off = 0;
    yo.list_wraps = 0;
    yo.list_idle = 0;
    yo.list_wait = 900;             /* ~15 s of list lines expected */
    yo_send("list");
}

void yo_vol_set(int v)
{
    char b[16];
    if (v < 0) v = 0;
    if (v > YO_VOL_MAX) v = YO_VOL_MAX;
    yo.vol = v;
    yo.vol_lock = 20;
    sprintf(b, "vol %d", v);
    yo_send(b);
}

void yo_play_station(int n)
{
    char b[16];
    sprintf(b, "play %d", n);
    yo_send(b);
}
