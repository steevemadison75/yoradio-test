#ifndef YORADIO_H
#define YORADIO_H

#define YO_MAX_STATIONS 2048    /* SD card libraries can hold thousands of tracks */
#define YO_NAME_LEN     40
#define YO_TITLE_LEN    96
#define YO_LOG_LINES    16
#define YO_LOG_COLS     38
#define YO_LIST_BASE    1
#define YO_VOL_MAX      100     /* volume ceiling used by this app (radio allows 254) */       /* number yoRadio uses for the first station */

typedef struct {
    int  vol;                   /* 0-254 */
    int  vol_lock;              /* frames to ignore echoed VOL after a local change */
    int  playing;
    int  station;               /* current station number */
    char name[YO_NAME_LEN];
    char title[YO_TITLE_LEN];
    int  nstations;
    char list[YO_MAX_STATIONS][YO_NAME_LEN];
    char last[76];              /* last non-state reply, shown on 2 footer lines */
    char log[YO_LOG_LINES][YO_LOG_COLS + 1];
    int  log_head;
    int  since_rx;              /* frames since last complete line */
    int  rx_lines;              /* total lines received */
    char ip[20];                /* device IP, when a reply mentions it */
    int  list_wait;             /* frames during which list lines are expected */
    int  list_idle;             /* frames since the last list entry arrived */
    int  list_got;              /* distinct stations received */
    int  list_missing;          /* gaps found after the last load */
    int  list_tries;            /* automatic re-requests done */
    int  list_bad;              /* list-looking lines that could not be parsed */
    int  eq[4];                 /* bass, mid, treble, balance: -16..16 */
    int  eq_known;              /* 1 once the radio reported them */
    int  mode;                  /* -1 unknown, 0 web radio, 1 SD card (needs patched firmware) */
    int  count;                 /* playlist size reported by the radio */
    int  t_cur, t_dur;          /* SD track position / length in seconds, -1 = none */
    int  t_sub;                 /* frame counter used to tick t_cur between polls */
    int  info_at;               /* frames until an automatic info request */
    int  list_wraps;            /* times the radio's 8-bit numbering wrapped (255 -> 0) */
    char lsample[3][76];        /* first raw list lines (diagnostics) */
    int  lsample_n;
    char raw[77];               /* last 76 raw bytes, non-printables as '.' */
} YoState;

extern YoState yo;

void yo_init(unsigned long baud);
void yo_poll(void);             /* call once per frame */
void yo_send(const char *cmd);  /* sends cmd + '\n' */

/* CLI commands */
void yo_prev(void);
void yo_next(void);
void yo_toggle(void);
void yo_stop(void);
void yo_start(void);
void yo_vol_set(int v);         /* vol x */
void yo_info(void);
void yo_list(void);
void yo_play_station(int n);    /* play x */
void yo_log_clear(void);
void yo_eq_set(int which, int v);   /* which: 0 bass, 1 mid, 2 treble, 3 balance */
void yo_mode_set(int m);        /* 0 = web radio, 1 = SD card (mp3) */
void yo_mode_toggle(void);

#endif
